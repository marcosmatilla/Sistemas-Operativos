#ifndef Clock_H
#define Clock_H

#define INTERVALBETWEENINTERRUPS 5 

// Functions prototypes
void Clock_Update();
int Clock_GetTime();

#endif
